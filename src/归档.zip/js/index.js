var _avatarBg = null;  // 用户选的头像
var _avatarElem = document.getElementById('avatar');
var _avatarFn = null;  // 用户选的头像框

var _tempImg = $('#tempImg');
var _cropper;

function changepic(){
    var reads= new FileReader();
    var target = document.getElementById('file');
    f = target.files[0];
    reads.readAsDataURL(f);
    reads.onload = function (e) {
        target.value = '';   //清空input的value，防止两次不能选择同一张图片
        _avatarBg = this.result;
        clipImg(_avatarBg);  // 裁剪图片 
    };
}

function clipImg(imgData){
    _tempImg.attr({'src': imgData});
    _tempImg.cropper({
        aspectRatio: 1 / 1,
        viewMode:1,
        dragMode: 'move',
        crop: function (e) {
            console.log(e.detail.x);
            console.log(e.detail.y);
            console.log(e.detail.width);
            console.log(e.detail.height);
            console.log(e.detail.rotate);
            console.log(e.detail.scaleX);
            console.log(e.detail.scaleY);
        }
    }); 
    _cropper = _tempImg.data('cropper');
}